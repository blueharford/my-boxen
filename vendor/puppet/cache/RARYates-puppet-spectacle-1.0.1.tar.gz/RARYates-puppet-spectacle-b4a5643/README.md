# Spectacle Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-spectacle.png)](https://travis-ci.org/boxen/puppet-spectacle)

## Usage

```puppet
include spectacle
```
[Spectacle Website](http://spectacleapp.com/)
## Required Puppet Modules

* boxen

